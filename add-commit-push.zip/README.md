# add-commit-push
# when run, -m allows for messages to be sent through
# -f forces through the confirmation
# Alias g5 for sprint 5 folder: os.system(echo 'alias g5="cd/Users/kairos8ight/Lewis/cpsc-20000/sprint5/add-commit-push"' >> ~/.zshrc)
# Alias acp for add-commit-push.py: os.system(echo 'alias acp="python3 /Users/kairos8ight/Lewis/cpsc-20000/sprint5/add-commit-push"' >> ~/.zshrc)
# update nano: os.system('source ~/.zshrc)